x = octave.dataset.occupationalStatus;

# TODO: Port to Octave
