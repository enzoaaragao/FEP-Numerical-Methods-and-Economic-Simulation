t = octave.dataset.Orange;

# TODO: Port coplot to Octave

# TODO: Linear model
