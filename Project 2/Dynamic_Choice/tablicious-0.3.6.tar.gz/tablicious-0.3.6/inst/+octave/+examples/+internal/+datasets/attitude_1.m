t = octave.dataset.attitude

octave.examples.plot_pairs (t);

# TODO: Display table summary

# TODO: Whatever those statistical linear-model plots are that R is doing

