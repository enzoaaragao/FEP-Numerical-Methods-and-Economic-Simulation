t = octave.dataset.freeny;

summary(t)

octave.examples.plot_pairs (removevars (t, "date"))

# TODO: Create linear model and print summary

# TODO: Linear model plot
