t = octave.dataset.PlantGrowth;

# TODO: Port anova to Octave
