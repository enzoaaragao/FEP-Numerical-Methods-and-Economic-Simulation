t = octave.dataset.swiss;

# TODO: Port linear model to Octave
