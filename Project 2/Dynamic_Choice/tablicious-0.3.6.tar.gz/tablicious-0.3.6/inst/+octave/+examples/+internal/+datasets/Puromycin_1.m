t = octave.dataset.Puromycin;

# TODO: Port example to Octave
