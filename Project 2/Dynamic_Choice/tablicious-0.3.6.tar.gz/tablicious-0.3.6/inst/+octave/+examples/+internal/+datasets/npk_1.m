t = octave.dataset.npk;

# TODO: Port aov() and LM to Octave
