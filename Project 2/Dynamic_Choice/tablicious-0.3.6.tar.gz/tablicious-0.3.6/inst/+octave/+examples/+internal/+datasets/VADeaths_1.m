octave.dataset.VADeaths;

# TODO: Port to Octave
