t = octave.dataset.quakes;

octave.examples.plot_pairs (t);
