t = octave.dataset.ToothGrowth;

octave.examples.coplot (t, "dose", "len", "supp");

# TODO: Port Lowess smoothing to Octave
