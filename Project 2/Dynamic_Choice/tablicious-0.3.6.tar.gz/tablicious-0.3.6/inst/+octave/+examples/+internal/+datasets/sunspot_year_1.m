t = octave.dataset.sunspot_year;

figure
plot (t.year, t.sunspots)
xlabel ("Year")
ylabel ("Sunspots")