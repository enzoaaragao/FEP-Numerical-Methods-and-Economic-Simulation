t = octave.dataset.precip;

# TODO: Port dot plot to Octave
