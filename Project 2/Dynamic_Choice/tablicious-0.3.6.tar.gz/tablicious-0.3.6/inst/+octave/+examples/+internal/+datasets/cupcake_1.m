t = octave.dataset.cupcake
plot(datenum(t.Month), t.Cupcake)
title ('“Cupcake” Google Searches'); xlabel ("Year"); ylabel ("Unknown popularity metric")
