t = octave.dataset.islands;

# TODO: Port dot chart to Octave
