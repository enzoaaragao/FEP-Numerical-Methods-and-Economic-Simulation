t = octave.dataset.OrchardSprays;

octave.examples.plot_pairs (t);
