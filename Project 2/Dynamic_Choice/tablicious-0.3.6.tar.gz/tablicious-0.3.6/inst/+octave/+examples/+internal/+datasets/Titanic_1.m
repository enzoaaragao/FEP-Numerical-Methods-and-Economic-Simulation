octave.dataset.Titanic;

# TODO: Port mosaic plot to Octave

# TODO: Check for higher survival rates in children and females
