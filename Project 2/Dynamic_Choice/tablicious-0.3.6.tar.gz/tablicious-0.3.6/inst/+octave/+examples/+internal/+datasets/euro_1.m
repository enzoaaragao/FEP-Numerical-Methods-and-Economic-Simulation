# TODO: Port this from R

# TODO: Example conversion

# TODO: "dot chart" showing euro-to-whatever conversion rates and vice versa
