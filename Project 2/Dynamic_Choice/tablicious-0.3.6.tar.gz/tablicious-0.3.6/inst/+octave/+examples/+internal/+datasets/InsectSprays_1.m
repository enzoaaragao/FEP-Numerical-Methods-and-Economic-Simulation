t = octave.dataset.InsectSprays;

# TODO: boxplot

# TODO: AOV plots
