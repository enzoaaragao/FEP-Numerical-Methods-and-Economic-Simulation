octave.dataset.WWWusage;

# TODO: Port the par() and plots to Octave
