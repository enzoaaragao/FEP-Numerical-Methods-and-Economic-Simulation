t = octave.dataset.ChickWeight

octave.examples.coplot (t, "Time", "weight", "Chick");
