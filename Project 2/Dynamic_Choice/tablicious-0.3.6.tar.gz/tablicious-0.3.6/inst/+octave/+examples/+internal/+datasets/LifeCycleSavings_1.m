t = octave.dataset.LifeCycleSavings;

# TODO: linear model

# TODO: pairs plot with Lowess smoothed line
